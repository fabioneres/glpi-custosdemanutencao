# Relatório cronológico de alterações — Custos de Manutenção

**Período:** 01/07/2026 a 31/07/2026  
**Plugin:** `maintenancecosts` (Custos de Manutenção)  
**Base de evidências:** histórico Git do repositório, tags de versão, `CHANGELOG.md` e notas de release presentes no próprio plugin.  
**Escopo:** alterações efetivamente registradas no código-fonte e nos artefatos do plugin; não inclui apenas atividades realizadas na VM sem registro no repositório.

## Resumo executivo

No período, o plugin evoluiu da versão **1.0.0** para a **1.0.12**. O trabalho concentrou-se em quatro frentes:

1. consolidação do vínculo entre chamados, materiais consumidos e centros de custo;
2. integração dos centros de custo Antigo e Novo com o FormCreator e a pesquisa nativa do GLPI;
3. correções de instalação, empacotamento e publicação das releases;
4. estabilidade do lançamento de materiais SINAPI e da consulta de preços/cotações.

Foram identificados **14 commits** no intervalo, além das tags de release. Não há commits registrados entre **28/07 e 31/07/2026**.

## Linha do tempo

### 01/07/2026 — Consolidação da versão 1.0.0 e ajustes iniciais

**Versões/publicações:** 1.0.0 e 1.0.1.

- Consolidado o fluxo operacional para materiais consumidos, centros de custo, contratos e relatórios.
- Criada a classe de vínculo de centro de custo ao chamado (`TicketCostCenter`) e a respectiva estrutura de instalação/migração.
- Disponibilizados os objetos de centros de custo Antigo e Novo para utilização pelo FormCreator.
- Reforçada a integração de materiais consumidos com custos de chamados e contratos, mantendo o valor unitário aplicado no lançamento.
- Introduzida a aba própria **Centro de Custos** no chamado, evitando duplicidade com a aba de materiais consumidos.
- Melhorada a busca de centros de custo: pesquisa por código com ou sem pontuação.
- Corrigidos rótulos e textos com acentuação exibida incorretamente em telas, importação, exportação e vínculos de chamado.
- Adicionados materiais de apoio para homologação: checklist, manual de uso e registro de validação.

**Rastreabilidade Git:** `dca5830`, `c416a08`, `691745a`, `e9ef091`.

### 02/07/2026 — Integração de centros de custo com o FormCreator

**Versões/publicações:** 1.0.2 e 1.0.3.

- Padronizada a apresentação dos centros de custo Antigo e Novo no FormCreator no formato `código - nome`.
- Implementada pesquisa de centros de custo por nome, código formatado e código sem pontuação.
- Direcionados os campos do FormCreator ao endpoint AJAX do próprio plugin.
- Mantida compatibilidade para carregamento de valores já selecionados por ID.

**Rastreabilidade Git:** `777b63c`, `9b7f8db`, `b2132ff`.

### 03/07/2026 — Preenchimento automático de data de consumo

**Versão/publicação:** 1.0.4.

- O formulário de lançamento de materiais passou a preencher automaticamente a data atual de consumo ao abrir.
- A data continuou editável pelo usuário.
- Incluído fallback no backend para gravar a data atual caso o campo seja enviado vazio.

**Rastreabilidade Git:** `2c39133`.

### 04/07/2026 — Correções de FormCreator, pesquisa nativa e integridade do setup

**Versão/publicação:** 1.0.5; correção posteriormente etiquetada como 1.0.6.

- Corrigido o prefixo visual indevido `nn` em descrições de chamados criados via FormCreator.
- Corrigida a pesquisa nativa de chamados por **Centro de Custos Antigo** e **Centro de Custos Novo**.
- Ajustado o mapeamento de `CostCenterLegacy` para compatibilidade com Search, dropdowns e FormCreator.
- Restauradas em `setup.php` as funções de pré-requisito e versão do plugin, após identificação de arquivo truncado durante a publicação.
- Registrados cenários de homologação para combinações de centros de custo Antigo/Novo e filtros nativos.

**Rastreabilidade Git:** `4e35cf0`, `04524f1`; tag `v1.0.6` aponta para a correção de `setup.php`.

### 06/07/2026 — Reempacotamento para instalação segura

**Versão/publicação:** 1.0.7.

- Regenerado o pacote de instalação a partir da árvore local validada em homologação.
- Corrigida a publicação de `setup.php`, `hook.php`, telas `front/` e classes `src/` que poderiam produzir tela branca ou falha de instalação em Linux.
- Preservados os ajustes recentes de FormCreator, dropdowns de centros de custo e pesquisa nativa.
- Disponibilizado novo ZIP de atualização manual.

**Observação técnica:** este commit possui alterações extensas também por normalização/regravação de arquivos; o escopo funcional acima é o registrado nas notas de release.

**Rastreabilidade Git:** `c0fa90c`.

### 07/07/2026 — Correção de edição de centros de custo

**Versão/publicação:** 1.0.8.

- Restaurada a ação **Salvar** ao editar registros de Centro de Custo Novo e Centro de Custo Antigo.
- Mantido o botão **Adicionar** para novos cadastros.
- Removida a dependência do rodapé automático do GLPI nesses formulários, garantindo consistência na edição.

**Rastreabilidade Git:** `5ead5e9`.

### 08/07/2026 — Sincronização dual de centros de custo no FormCreator

**Versão/publicação:** 1.0.9.

- Corrigido o sincronismo do FormCreator para persistir simultaneamente as seleções Antigo e Novo.
- Mantido o centro de custo Antigo como referência principal quando necessário.
- Evitado que uma única seleção substituísse a outra no vínculo do chamado.

**Rastreabilidade Git:** `153f254`.

### 09/07 a 20/07/2026 — Sem alterações registradas

Não foram identificados commits ou tags do plugin neste intervalo.

### 21/07/2026 — Correções de instalação e refinamentos de centro de custo

**Versão/publicação:** 1.0.10.

- Ajustada a rotina de instalação/upgrade para ambientes em que a camada de banco não disponibiliza `listIndexes()`, utilizando `SHOW INDEX` como alternativa.
- Corrigido o índice composto de `ticketcostcenters`, passando a permitir um centro Antigo e um Novo por chamado sem conflito de chave única.
- Consolidado o salvamento da aba **Centro de Custos** para seleções independentes das bases Antigo e Novo.
- Refinados os dropdowns vinculados e o carregamento versionado de JavaScript/CSS, reduzindo efeito de cache antigo após atualização.
- Aproximado o cabeçalho visual das tabelas do plugin do padrão nativo do GLPI.

**Rastreabilidade Git:** `078de56`.

### 22/07 a 26/07/2026 — Sem alterações registradas

Não foram identificados commits ou tags do plugin neste intervalo.

### 27/07/2026 — Estabilidade do lançamento de materiais e busca SINAPI

**Versões/publicações:** 1.0.11 e 1.0.12.

**1.0.11 — lançamento de materiais e cotação**

- Corrigida a abertura de **Adicionar material** quando o deploy parcial não publicava `ticketmaterial-v3.js`.
- Implementado fallback para `ticketmaterial-v2.js` ou `ticketmaterial.js` quando o asset principal não estiver disponível no servidor.
- Atualizados os scripts de deploy de VM e produção para publicar explicitamente `ticketmaterial-v3.js`.
- Ajustada a tela **Cotação/Mercado** para listar somente o preço vigente de cada material; competências anteriores permanecem no histórico de preços.

**1.0.12 — busca de materiais SINAPI**

- Ajustada a busca AJAX de materiais consumidos para consultar primeiro os materiais e, depois, filtrar a existência de preço do tipo selecionado.
- Reforçada a pesquisa por código e nome, com normalização de códigos sem pontuação.
- Corrigido o caso de materiais SINAPI já importados não aparecerem no dropdown de lançamento.
- Corrigido o registro de JavaScript e CSS em `setup.php` para ambientes que não aceitam caminhos de hook com query string.
- Corrigidos textos com acentuação quebrada e aliases de cabeçalhos legados do importador.

**Rastreabilidade Git:** `8699af7`, `332d5c6`.

### 28/07 a 31/07/2026 — Sem alterações registradas

Não foram identificados commits ou tags do plugin neste intervalo.

## Versões identificadas no período

| Data | Versão | Natureza principal |
|---|---:|---|
| 01/07 | 1.0.0 | Consolidação funcional e estrutura de centros de custo/chamado |
| 01/07 | 1.0.1 | Busca e aba própria de centros de custo; correções de acentuação |
| 02/07 | 1.0.2 | Exibição e busca amigável no FormCreator |
| 02/07 | 1.0.3 | Endpoint AJAX e integração dos centros de custo no FormCreator |
| 03/07 | 1.0.4 | Data automática no lançamento de consumo |
| 04/07 | 1.0.5 | FormCreator, pesquisa nativa e centros Antigo/Novo |
| 06/07 | 1.0.6 | Hotfix de publicação do `setup.php` |
| 06/07 | 1.0.7 | Reempacotamento seguro para instalação Linux |
| 07/07 | 1.0.8 | Salvar em cadastros de centros de custo |
| 08/07 | 1.0.9 | Sincronismo dual Antigo/Novo no FormCreator |
| 21/07 | 1.0.10 | Upgrade, índice e dropdowns de centros de custo |
| 27/07 | 1.0.11 | Asset do formulário de materiais e preço vigente de cotação |
| 27/07 | 1.0.12 | Busca SINAPI, assets e acentuação/importação |

## Situação ao final do período

Ao fim de 31/07/2026, a última versão registrada no repositório era a **1.0.12** (`tag v1.0.12`, commit `332d5c6`). O foco final do mês foi assegurar que materiais SINAPI importados fossem localizados e lançados corretamente, inclusive após atualizações parciais do plugin.

## Observações de auditoria

- O diretório de trabalho contém artefatos não versionados de builds e ZIPs. Eles não foram usados para inferir mudanças funcionais, pois não têm rastreabilidade equivalente a commit/tag.
- As datas acima correspondem às datas de commit e/ou tag registradas no repositório. Uma instalação em VM ou produção pode ter ocorrido em data diferente.
- Este relatório não altera o código do plugin; ele apenas documenta o histórico de julho de 2026.
