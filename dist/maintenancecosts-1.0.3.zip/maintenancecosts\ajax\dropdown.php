<?php

use GlpiPlugin\Maintenancecosts\Config;
use GlpiPlugin\Maintenancecosts\CostCenter;
use GlpiPlugin\Maintenancecosts\CostCenterLegacy;
use GlpiPlugin\Maintenancecosts\Material;
use GlpiPlugin\Maintenancecosts\Price;

ob_start();
if (!defined('GLPI_ROOT')) {
   require_once dirname(__DIR__, 3) . '/inc/includes.php';
}
require_once dirname(__DIR__) . '/bootstrap.php';
if (ob_get_length() !== false) {
   ob_clean();
}

header('Content-Type: application/json; charset=UTF-8');

Session::checkLoginUser();

$type = (string) ($_GET['type'] ?? $_POST['type'] ?? '');
if ($type === 'material'
   && !Config::canViewConsumption()
   && !Config::canViewReports()
   && !Config::canViewMaterials()
) {
   http_response_code(403);
   echo json_encode(['results' => []]);
   exit;
}
if (($type === 'costcenter' || $type === 'costcenter_legacy')
   && !Config::canViewConsumption()
   && !Config::canViewReports()
   && !Config::canViewCostCenters()
) {
   http_response_code(403);
   echo json_encode(['results' => []]);
   exit;
}
if ($type === 'contract' && !Config::canViewConsumption() && !Config::canViewReports()) {
   http_response_code(403);
   echo json_encode(['results' => []]);
   exit;
}

$search = trim((string) ($_GET['q'] ?? $_POST['q'] ?? $_GET['term'] ?? $_POST['term'] ?? ''));
$page = max(1, (int) ($_GET['page'] ?? $_POST['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;
$oneId = max(0, (int) ($_GET['_one_id'] ?? $_POST['_one_id'] ?? $_GET['one_id'] ?? $_POST['one_id'] ?? 0));
$priceType = Config::normalizePriceType((string) ($_GET['price_type'] ?? $_POST['price_type'] ?? 'sinapi'));

if ($type === 'material') {
   show_materials($search, $limit, $offset, $priceType, $oneId);
}

if ($type === 'costcenter') {
   show_costcenters($search, $limit, $offset, $oneId);
}

if ($type === 'costcenter_legacy') {
   show_costcenters_legacy($search, $limit, $offset, $oneId);
}

if ($type === 'contract') {
   show_contracts($search, $limit, $offset);
}

http_response_code(400);
echo json_encode(['results' => []]);

function show_materials(string $search, int $limit, int $offset, string $priceType, int $oneId = 0): void
{
   global $DB;

   $materialTable = Material::getTable();
   $priceTable = Price::getTable();
   $where = [
      $materialTable . '.is_active' => 1,
      $priceTable . '.price_type'   => Config::normalizePriceType($priceType),
   ];
   if ($oneId > 0) {
      $where[$materialTable . '.id'] = $oneId;
   }
   if ($search !== '') {
      $like = '%' . $search . '%';
      $where[] = [
         'OR' => [
            [$materialTable . '.code' => ['LIKE', $like]],
            [$materialTable . '.name' => ['LIKE', $like]],
            [$materialTable . '.description' => ['LIKE', $like]],
            [$priceTable . '.competence' => ['LIKE', $like]],
            [$priceTable . '.source' => ['LIKE', $like]],
         ],
      ];
   }

   $rows = $DB->request([
      'SELECT' => [
         $materialTable . '.id AS id',
         $materialTable . '.code AS code',
         $materialTable . '.name AS name',
         $materialTable . '.unit AS unit',
      ],
      'FROM'   => $priceTable,
      'LEFT JOIN' => [
         $materialTable => [
            'FKEY' => [$priceTable => 'plugin_maintenancecosts_materials_id', $materialTable => 'id'],
         ],
      ],
      'WHERE'  => $where,
      'GROUPBY' => [
         $materialTable . '.id',
         $materialTable . '.code',
         $materialTable . '.name',
         $materialTable . '.unit',
      ],
      'ORDER'  => [$materialTable . '.code ASC', $materialTable . '.name ASC'],
      'START'  => $offset,
      'LIMIT'  => $limit + 1,
   ]);

   $results = [];
   $fetched = 0;
   foreach ($rows as $row) {
      $fetched++;
      if (count($results) >= $limit) {
         break;
      }
      $label = trim((string) $row['code']) !== ''
         ? sprintf('%s - %s', $row['code'], $row['name'])
         : (string) $row['name'];
      if (trim((string) $row['unit']) !== '') {
         $label .= ' (' . $row['unit'] . ')';
      }
      $results[] = ['id' => (int) $row['id'], 'text' => $label];
   }

   echo json_encode([
      'results'    => $results,
      'pagination' => ['more' => $fetched > $limit],
   ]);
   exit;
}

function show_costcenters(string $search, int $limit, int $offset, int $oneId = 0): void
{
   global $DB;

   $where = [];
   if ($DB->fieldExists(CostCenter::getTable(), 'is_active')) {
      $where['is_active'] = 1;
   }
   if ($oneId > 0) {
      $where['id'] = $oneId;
   }
   if ($search !== '') {
      $like = '%' . $search . '%';
      // Normaliza o termo removendo pontos e hifens para busca tolerante
      // Ex: "001005000" encontra "001.005.000" armazenado no banco
      $searchNorm = preg_replace('/[.\-\/]/', '', $search);
      $orConditions = [
         'name' => ['LIKE', $like],
         'code' => ['LIKE', $like],
      ];
      if ($searchNorm !== '') {
         $orConditions[] = new \QueryExpression(
            "REPLACE(REPLACE(`code`, '.', ''), '-', '') LIKE " . $DB->quote('%' . $searchNorm . '%')
         );
      }
      $where[] = ['OR' => $orConditions];
   }

   $rows = $DB->request([
      'SELECT' => ['id', 'code', 'name'],
      'FROM'   => CostCenter::getTable(),
      'WHERE'  => $where,
      'ORDER'  => ['name ASC'],
      'START'  => $offset,
      'LIMIT'  => $limit + 1,
   ]);

   $results = [];
   $fetched = 0;
   foreach ($rows as $row) {
      $fetched++;
      if (count($results) >= $limit) {
         break;
      }
      $label = trim((string) $row['code']) !== ''
         ? sprintf('%s - %s', $row['code'], $row['name'])
         : (string) $row['name'];
      $results[] = ['id' => (int) $row['id'], 'text' => $label];
   }

   echo json_encode([
      'results'    => $results,
      'pagination' => ['more' => $fetched > $limit],
   ]);
   exit;
}

function show_costcenters_legacy(string $search, int $limit, int $offset, int $oneId = 0): void
{
   global $DB;

   $where = [];
   if ($DB->fieldExists(CostCenterLegacy::getTable(), 'is_active')) {
      $where['is_active'] = 1;
   }
   if ($oneId > 0) {
      $where['id'] = $oneId;
   }
   if ($search !== '') {
      $like = '%' . $search . '%';
      // Normaliza o termo removendo pontos e hifens para busca tolerante
      // Ex: "001005000" encontra "001.005.000" armazenado no banco
      $searchNorm = preg_replace('/[.\-\/]/', '', $search);
      $orConditions = [
         'code'       => ['LIKE', $like],
         'campus'     => ['LIKE', $like],
         'department' => ['LIKE', $like],
         'address'    => ['LIKE', $like],
         'usage_type' => ['LIKE', $like],
      ];
      if ($searchNorm !== '') {
         $orConditions[] = new \QueryExpression(
            "REPLACE(REPLACE(`code`, '.', ''), '-', '') LIKE " . $DB->quote('%' . $searchNorm . '%')
         );
      }
      $where[] = ['OR' => $orConditions];
   }

   $rows = $DB->request([
      'SELECT' => ['id', 'code', 'campus', 'department'],
      'FROM'   => CostCenterLegacy::getTable(),
      'WHERE'  => $where,
      'ORDER'  => ['code ASC', 'department ASC'],
      'START'  => $offset,
      'LIMIT'  => $limit + 1,
   ]);

   $results = [];
   $fetched = 0;
   foreach ($rows as $row) {
      $fetched++;
      if (count($results) >= $limit) {
         break;
      }
      $parts = [];
      if (trim((string) ($row['code'] ?? '')) !== '') {
         $parts[] = (string) $row['code'];
      }
      if (trim((string) ($row['department'] ?? '')) !== '') {
         $parts[] = (string) $row['department'];
      } elseif (trim((string) ($row['campus'] ?? '')) !== '') {
         $parts[] = (string) $row['campus'];
      }
      $label = count($parts) ? implode(' - ', $parts) : (string) $row['id'];
      $results[] = ['id' => (int) $row['id'], 'text' => $label];
   }

   echo json_encode([
      'results'    => $results,
      'pagination' => ['more' => $fetched > $limit],
   ]);
   exit;
}

function show_contracts(string $search, int $limit, int $offset): void
{
   global $DB;

   if (!$DB->tableExists('glpi_contracts')) {
      echo json_encode(['results' => [], 'pagination' => ['more' => false]]);
      exit;
   }

   $where = ['is_deleted' => 0];
   if ($search !== '') {
      $like = '%' . $search . '%';
      $where[] = [
         'OR' => [
            'name' => ['LIKE', $like],
            'num'  => ['LIKE', $like],
         ],
      ];
   }

   $rows = $DB->request([
      'SELECT' => ['id', 'name', 'num'],
      'FROM'   => 'glpi_contracts',
      'WHERE'  => $where,
      'ORDER'  => ['name ASC'],
      'START'  => $offset,
      'LIMIT'  => $limit + 1,
   ]);

   $results = [];
   $fetched = 0;
   foreach ($rows as $row) {
      $fetched++;
      if (count($results) >= $limit) {
         break;
      }
      $label = trim((string) ($row['num'] ?? '')) !== ''
         ? sprintf('%s - %s', $row['num'], $row['name'])
         : sprintf('%d - %s', (int) $row['id'], $row['name']);
      $results[] = ['id' => (int) $row['id'], 'text' => $label];
   }

   echo json_encode([
      'results'    => $results,
      'pagination' => ['more' => $fetched > $limit],
   ]);
   exit;
}
